const express = require('express');
const router = express.Router();
const db = require('../db');

// Create a user_prog
router.post('/', (req, res) => {
  const { user_id, food_id, image } = req.body;
  const query = 'INSERT INTO user_prog (user_id, food_id, image) VALUES ($1, $2, $3) RETURNING *';
  const values = [user_id, food_id, image];

  db.query(query, values)
    .then(result => res.json(result.rows[0]))
    .catch(error => res.status(500).json({ error }));
});

// Read all user_prog records
router.get('/', (req, res) => {
  const query = 'SELECT * FROM user_prog';

  db.query(query)
    .then(result => res.json(result.rows))
    .catch(error => res.status(500).json({ error }));
});

// Read a specific user_prog record
router.get('/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM user_prog WHERE id = $1';
  const values = [id];

  db.query(query, values)
    .then(result => {
      if (result.rows.length === 0) {
        res.status(404).json({ message: 'Record not found' });
      } else {
        res.json(result.rows[0]);
      }
    })
    .catch(error => res.status(500).json({ error }));
});

// Update a user_prog record
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { user_id, food_id, image } = req.body;
  const query = 'UPDATE user_prog SET user_id = $1, food_id = $2, image = $3, time_update = current_timestamp WHERE id = $4 RETURNING *';
  const values = [user_id, food_id, image, id];

  db.query(query, values)
    .then(result => {
      if (result.rows.length === 0) {
        res.status(404).json({ message: 'Record not found' });
      } else {
        res.json(result.rows[0]);
      }
    })
    .catch(error => res.status(500).json({ error }));
});

// Delete a user_prog record
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM user_prog WHERE id = $1';
  const values = [id];

  db.query(query, values)
    .then(() => res.json({ message: 'Record deleted successfully' }))
    .catch(error => res.status(500).json({ error }));
});

module.exports = router;