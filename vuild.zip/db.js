const { Pool, Client } = require("pg")

// const pool = new Client({
//     user: "postgres",
//     host: "containers-us-west-143.railway.app",
//     database: "railway",
//     password: "GoLZRn8nFh9YgD8osXoS",
//     port: 5619
// })
const pool = new Client({
    user: "abbasuz1_abbas12",
    host: "localhost",
    database: "abbasuz1_foods",
    password: "*usU3Vzf&BBR",
    port: 5619
})
// const connectionString = 'postgres://default:aw6bRlf3hiAV@ep-divine-bird-a6gpq7y7.us-west-2.aws.neon.tech:5432/verceldb?sslmode=require';

// const pool = new Pool({
//   connectionString: connectionString,
//   dialectOptions: {
//     ssl: {
//       require: true,
//       rejectUnauthorized: false, // Это может быть необходимо в вашем окружении
//     },
//   },
// });
pool.connect(err => {
    if(err) {
        console.log("Connect Error");
    } else {
        console.log("Connect To PostgreSql");
    }
})

module.exports = pool